package com.example.map_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
